<?php
/**
 * Qihoo PHP FrameWork bootstrap file(QFrame)
 * @Writen by : cc <chenchao@360.cn>
 * @http://twiki.corp.qihoo.net/twiki/bin/view/Main/NewADDQFrame
 */

class QFrameHttp
{
    protected $_params = array();

    protected $_requestUri = NULL;

    protected $_baseUrl   = NULL;

    protected $_scriptUrl = NULL;

    protected $_pathInfo = NULL;

    public function __construct()
    {/*{{{*/
       $this->setRequestUri(); 
    }/*}}}*/

    public function __get($key)
    {/*{{{*/
        switch (true) 
        {
            case isset($this->_params[$key]):
                 return $this->_params[$key];
            case isset($_GET[$key]):
                 return $_GET[$key];
            case isset($_POST[$key]):
                 return $_POST[$key];
            case isset($_COOKIE[$key]):
                 return $_COOKIE[$key];
            case ($key == 'REQUEST_URI'):
                 return $this->getRequestUri();
            case ($key == 'PATH_INFO'):
                 return $this->getPathInfo();
            case isset($_SERVER[$key]):
                 return $_SERVER[$key];
            case isset($_ENV[$key]):
                 return $_ENV[$key];
            default:
                 return null;
        }
    }/*}}}*/

    public function get($key)
    {/*{{{*/
        return $this->__get($key);
    }/*}}}*/

    public function getRequest($key = null , $default = null)
    {/*{{{*/
        if(null === $key)
        {
            $res = array_merge($this->getPost(null,null) , $this->getQuery(null,null));
            return $res;
        }
        if(null !== ($res = $this->getQuery($key,null)))
        {
            return $res;
        }
        if(null !== ($res = $this->getPost($key , null)))
        {
            return $res;
        }

        return $default;
    }/*}}}*/

    public function getQuery($key = null, $default = null)
    {/*{{{*/
        if (null === $key) 
        {
            return $_GET;
        }

        return (isset($_GET[$key])) ? $_GET[$key] : $default;
    }/*}}}*/

    public function getPost($key = null, $default = null)
    {/*{{{*/
        if (null === $key) 
        {
            return $_POST;
        }

        return  (isset($_POST[$key])) ?  $_POST[$key] : $default;
    }/*}}}*/

    public function setRequestUri($requestUri=null)
    {/*{{{*/
        $this->_requestUri = $requestUri;
    }/*}}}*/

    public function getRequestUri()
	{/*{{{*/
		if($this->_requestUri===null)
		{
            // Not For IIS anyMore, for self define Rewrite rule! 
            // http://add.corp.qihoo.net/pages/viewpage.action?pageId=8756338
			if(isset($_SERVER['HTTP_X_REWRITE_URL']) && !empty($_SERVER['HTTP_X_REWRITE_URL'])) 
            {
				$this->_requestUri=$_SERVER['HTTP_X_REWRITE_URL'];
            }
			elseif(isset($_SERVER['REQUEST_URI']))
			{
				$this->_requestUri=$_SERVER['REQUEST_URI'];
				if(!empty($_SERVER['HTTP_HOST']))
				{
					if(strpos($this->_requestUri,$_SERVER['HTTP_HOST'])!==false)
						$this->_requestUri=preg_replace('/^\w+:\/\/[^\/]+/','',$this->_requestUri);
				}
				else
					$this->_requestUri=preg_replace('/^(http|https):\/\/[^\/]+/i','',$this->_requestUri);
			}
			elseif(isset($_SERVER['ORIG_PATH_INFO']))  // IIS 5.0 CGI
			{
				$this->_requestUri=$_SERVER['ORIG_PATH_INFO'];
				if(!empty($_SERVER['QUERY_STRING']))
					$this->_requestUri.='?'.$_SERVER['QUERY_STRING'];
            }else
            {
                return $this;
            }
		}
		return $this->_requestUri;
	}/*}}}*/

    public function setParam($key,$value)
    {/*{{{*/
        $this->_params[$key] = $value;  
    }/*}}}*/

    public function setParams($params)
    {/*{{{*/
        if(!empty($params))
        {
            foreach($params as $key => $name)
            {
                $this->_params[$key] = $name; 
            }
        }
    }/*}}}*/
    
    public function getBaseUrl()
	{/*{{{*/
		if($this->_baseUrl===null)
			$this->_baseUrl=rtrim(dirname($this->getScriptUrl()),'\\/');
		return $this->_baseUrl;
    }/*}}}*/
    
    public function setBaseUrl($value)
	{/*{{{*/
		$this->_baseUrl=$value;
	}/*}}}*/
    
    /**
	 * Returns the relative URL of the entry script.
	 * this method referenced Zend_Controller_Request_Http in Zend Framework.
	 */
    public function getScriptUrl()
	{/*{{{*/
		if($this->_scriptUrl===null)
		{
			$scriptName=basename($_SERVER['SCRIPT_FILENAME']);
			if(basename($_SERVER['SCRIPT_NAME'])===$scriptName)
				$this->_scriptUrl=$_SERVER['SCRIPT_NAME'];
			elseif(basename($_SERVER['PHP_SELF'])===$scriptName)
				$this->_scriptUrl=$_SERVER['PHP_SELF'];
			elseif(isset($_SERVER['ORIG_SCRIPT_NAME']) && basename($_SERVER['ORIG_SCRIPT_NAME'])===$scriptName)
				$this->_scriptUrl=$_SERVER['ORIG_SCRIPT_NAME'];
			elseif(($pos=strpos($_SERVER['PHP_SELF'],'/'.$scriptName))!==false)
				$this->_scriptUrl=substr($_SERVER['SCRIPT_NAME'],0,$pos).'/'.$scriptName;
			elseif(isset($_SERVER['DOCUMENT_ROOT']) && strpos($_SERVER['SCRIPT_FILENAME'],$_SERVER['DOCUMENT_ROOT'])===0)
				$this->_scriptUrl=str_replace('\\','/',str_replace($_SERVER['DOCUMENT_ROOT'],'',$_SERVER['SCRIPT_FILENAME']));
			else
                return $this;
		}
		return $this->_scriptUrl;
	}/*}}}*/

    public function setScriptUrl($value)
	{/*{{{*/
		$this->_scriptUrl='/'.trim($value,'/');
	}/*}}}*/

    public function getPathInfo()
	{/*{{{*/
		if($this->_pathInfo===null)
		{
			$pathInfo=$this->getRequestUri();

			if(($pos=strpos($pathInfo,'?'))!==false)
            {
			   $pathInfo=substr($pathInfo,0,$pos);
            }

			$pathInfo=$this->decodePathInfo($pathInfo);
			$scriptUrl=$this->getScriptUrl();
			$baseUrl=$this->getBaseUrl();
			if(strpos($pathInfo,$scriptUrl)===0)
            {
				$pathInfo=substr($pathInfo,strlen($scriptUrl));
            }elseif($baseUrl==='' || strpos($pathInfo,$baseUrl)===0)
            {
				$pathInfo=substr($pathInfo,strlen($baseUrl));
            }elseif(strpos($_SERVER['PHP_SELF'],$scriptUrl)===0)
            {
				$pathInfo=substr($_SERVER['PHP_SELF'],strlen($scriptUrl));
            }else
            {
                return $this;
            }

			$this->_pathInfo=trim($pathInfo,'/');
		}
		return $this->_pathInfo;
	}/*}}}*/

    public function setPathInfo($pathInfo)
    {/*{{{*/
        $this->_pathInfo = $pathInfo;
    }/*}}}*/
    
    protected function decodePathInfo($pathInfo)
	{/*{{{*/
		$pathInfo = urldecode($pathInfo);

		// is it UTF-8?
		// http://w3.org/International/questions/qa-forms-utf-8.html
		if(preg_match('%^(?:
		   [\x09\x0A\x0D\x20-\x7E]            # ASCII
		 | [\xC2-\xDF][\x80-\xBF]             # non-overlong 2-byte
		 | \xE0[\xA0-\xBF][\x80-\xBF]         # excluding overlongs
		 | [\xE1-\xEC\xEE\xEF][\x80-\xBF]{2}  # straight 3-byte
		 | \xED[\x80-\x9F][\x80-\xBF]         # excluding surrogates
		 | \xF0[\x90-\xBF][\x80-\xBF]{2}      # planes 1-3
		 | [\xF1-\xF3][\x80-\xBF]{3}          # planes 4-15
		 | \xF4[\x80-\x8F][\x80-\xBF]{2}      # plane 16
		)*$%xs', $pathInfo))
		{
			return $pathInfo;
		}
		else
		{
			return utf8_encode($pathInfo);
		}
	}/*}}}*/

}

?>
