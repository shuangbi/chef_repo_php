<?php
/**
 * Qihoo PHP FrameWork bootstrap file(QFrame)
 * @Writen by : cc <chenchao@360.cn>
 * @Wiki  : http://add.corp.qihoo.net:8360/display/platform/QFrame
 * @Demand: http://task.corp.qihoo.net/browse/QIHOOPHPFRAM
 */

class QFrame extends QFrameBase
{
}
?>
